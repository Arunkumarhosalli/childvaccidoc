from flask import Flask, request, jsonify
from flask_cors import CORS
import smtplib
from email.mime.text import MIMEText
import os

app = Flask(__name__)
CORS(app)

@app.route('/send', methods=['POST'])
def send():
    try:
        data = request.json

        required = ['to', 'subject', 'body']
        if not all(field in data for field in required):
            return jsonify({"error": "Missing required fields"}), 400

        msg = MIMEText(data['body'])
        msg['Subject'] = data['subject']
        msg['From'] = os.getenv('SMTP_FROM', 'vvinu6516@gmail.com')
        msg['To'] = data['to']

        with smtplib.SMTP(os.getenv('SMTP_SERVER', 'smtp.gmail.com'),
                          int(os.getenv('SMTP_PORT', 587))) as server:
            server.starttls()
            server.login(os.getenv('SMTP_USER'), os.getenv('SMTP_APP_PASSWORD'))
            server.send_message(msg)

        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5002, debug=True)

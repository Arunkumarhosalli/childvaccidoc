from flask import Flask, request, jsonify
from flask_cors import CORS
from twilio.rest import Client
import os

app = Flask(__name__)
CORS(app)

@app.route('/send', methods=['POST'])
def send():
    try:
        data = request.json

        required = ['country_code', 'numbers', 'message']
        if not all(field in data for field in required):
            return jsonify({"error": "Missing required fields"}), 400

        client = Client(
            os.getenv('TWILIO_ACCOUNT_SID'),
            os.getenv('TWILIO_AUTH_TOKEN')
        )

        for number in data['numbers']:
            client.messages.create(
                body=data['message'],
                from_=os.getenv('TWILIO_WHATSAPP_NUMBER'),
                to=f"whatsapp:{data['country_code']}{number.strip()}"
            )

        return jsonify({"status": "success", "sent_to": data['numbers']})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5001, debug=True)
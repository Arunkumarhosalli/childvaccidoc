from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import requests

app = Flask(__name__, static_url_path='/static')
CORS(app)

# Correct service endpoints
SERVICES = {
    "email": "http://localhost:5002",
    "whatsapp": "http://localhost:5001"
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/email')
def email_service():
    return render_template('email.html')

@app.route('/whatsapp')
def whatsapp_service():
    return render_template('whatsapp.html')

@app.route('/api/<service>/send', methods=['POST'])
def proxy(service):
    try:
        response = requests.post(
            f"{SERVICES[service]}/send",
            json=request.json,
            timeout=5
        )
        return (response.content, response.status_code, response.headers.items())
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host="0.0.0.0",port=5000, debug=True)

// Email Form Handler
if (document.getElementById('emailForm')) {
    document.getElementById('emailForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const payload = {
            to: document.getElementById('to').value,
            subject: document.getElementById('subject').value,
            body: document.getElementById('body').value
        };

        try {
            const response = await fetch('/api/email/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await response.json();
            
            const statusEl = document.getElementById('status');
            statusEl.textContent = response.ok 
                ? "✓ Email sent successfully!" 
                : `✗ Error: ${data.error || 'Failed to send'}`;
            statusEl.className = response.ok ? 'success' : 'error';
            statusEl.style.display = 'block';
            
        } catch (error) {
            console.error('Email send error:', error);
        }
    });
}

// WhatsApp Form Handler
if (document.getElementById('whatsappForm')) {
    document.getElementById('whatsappForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const payload = {
            country_code: document.getElementById('countryCode').value,
            numbers: document.getElementById('numbers').value.split(','),
            message: document.getElementById('message').value
        };

        try {
            const response = await fetch('/api/whatsapp/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const data = await response.json();
            
            const statusEl = document.getElementById('status');
            if (response.ok) {
                statusEl.textContent = `✓ Sent to ${data.sent_to.length} numbers!`;
                statusEl.className = 'success';
                
                // Show progress
                const progressEl = document.getElementById('progress');
                progressEl.innerHTML = data.sent_to.map(num => 
                    `<div class="progress-item">✓ ${num}</div>`
                ).join('');
            } else {
                statusEl.textContent = `✗ Error: ${data.error || 'Failed to send'}`;
                statusEl.className = 'error';
            }
            statusEl.style.display = 'block';
            
        } catch (error) {
            console.error('WhatsApp send error:', error);
        }
    });
}
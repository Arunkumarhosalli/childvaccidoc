# This is a Microservice application that has Email and Bulk WhatsApp Messaging
This uses my personal Email-ID and app password for sending mails. To send WhatsApp messages it uses Twilio's WhatsApp Sandbox.
<br>
To join the WhatsApp Sandbox send the following message to +1(415)523-8886:
```
join refused-soon
```

## How to run the app
Execute the following commands to run the backend of the app, which is app.py:
```bash
python app.py
```
This will run the backend on the localhost on the port 5000, which is specified and can be changed to make both the app work properly ensure you change the port number of one of the service to some other port, or else it may lead to a port conflict.

## Go to index.html
Open the index webpage of the service you want to use and fill in the required details.

# DevSecOps Approach: Setup and Configurations

## Server Setup


#### If using an EC2 instance of type t2.micro
```bash
sudo fallocate -l 4G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### Set JAVA_HOME

```ini
JAVA_HOME="/usr/lib/jvm/java-21-openjdk-amd64"
```

## Terraform and Ansible

### Install Terraform on Jenkins Server
Install TF using the following commands:
```bash
wget -O - https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(grep -oP '(?<=UBUNTU_CODENAME=).*' /etc/os-release || lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install terraform
```
#### Run the TF code
Run the tf code using the following commands:
```bash
terraform plan
terraform apply --auto-approve
```

### Install Ansible
Make sure you have python installed before ansible as ansible uses python to execute the instructions:

##### Run this command to check the if python exists on the machine:
```bash
python --version
```

Install ansible using the following commands:
```bash
sudo apt update
sudo apt install software-properties-common
sudo add-apt-repository --yes --update ppa:ansible/ansible

sudo apt install ansible
```

### Run the ansible playbook
Run the playbook to install the required dependencies of the application and setup a webserver using the following command:
```bash
ansible-playbook ec2-conf.yml
```
